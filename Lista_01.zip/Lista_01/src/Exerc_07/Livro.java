package Exerc_07;

public class Livro {
    String nomeLivro;
    String autor;
    int quantidadePagina;
    String editora;

    public Livro(String nomeLivro, String autor, int quantidadePagina, String editora) {
        this.nomeLivro = nomeLivro;
        this.autor = autor;
        this.quantidadePagina = quantidadePagina;
        this.editora = editora;
    }
}
