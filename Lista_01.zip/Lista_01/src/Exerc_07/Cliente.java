package Exerc_07;

public class Cliente {
    String nome;
    String cpf;
    String dataNascimento;
    String telefone;

    public Cliente(String nome, String cpf, String dataNascimento, String telefone) {
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.telefone = telefone;
    }
}
